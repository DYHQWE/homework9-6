use std::ops::Deref;
use std::mem::ManuallyDrop;

struct MyRc<T> {
    data: ManuallyDrop<T>,
    ref_count: usize,
}

impl<T> MyRc<T> {
    fn new(data: T) -> Self {
        MyRc {
            data: ManuallyDrop::new(data),
            ref_count: 1,
        }
    }

}

impl<T> Deref for MyRc<T> {
    type Target = T;

    fn deref(&self) -> &T {
        &*self.data
    }
}

impl<T> Drop for MyRc<T> {
    fn drop(&mut self) {
        if self.ref_count == 1 {
            unsafe {
                ManuallyDrop::drop(&mut self.data);
            }
        } else {
            self.ref_count -= 1;
        }
    }
}

fn main() {
    let mut original = MyRc::new(String::from("MyRc!"));


    println!("Original: {}", *original);


    // Simulate dropping references
    original = MyRc::new(String::from("Reassign Original"));

    println!("Original: {}", *original);
}
